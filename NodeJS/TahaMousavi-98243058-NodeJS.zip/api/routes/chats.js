const express = require("express");
const router = express.Router();

const checkAuth = require("../middleware/check-auth");
const mongoose = require("mongoose");

const User = require("../models/user");
const Chat = require("../models/chat");
const Message = require("../models/message");

router.get("/", (req, res, next) => {
    User.find({ email: req.userData.email })
        .exec()
        .then(user => {
            if (user.length >= 1) {
                Chat.find({ $or: [{ user1: user[0].primaryId }, { user2: user[0].primaryId }] })
                    .exec()
                    .then(chat => {
                        chat.find({})
                            .select('-_id user1ID user2ID',)
                            .sort({ lastmessageDate: 'descending', id: 'descending' })
                            .exec((err, docs) => {
                                const chatsListResponse = docs.map(item => {
                                    if (item.messages.length > 0) {
                                        const newMap = {};

                                        newMap.name = item.name;
                                        if (item.user1ID == user[0].primaryId) {
                                            newMap.userId = item.user2ID;
                                        } else {
                                            newMap.userId = item.user1ID;
                                        }
                                        User.find({ primaryId: newMap.userId })
                                            .exec()
                                            .then(user2 => {
                                                newMap.name = user2.name;
                                            })
                                        return newMap;
                                    }
                                })

                                return res.status(200).json(
                                    {
                                        "chats": chatsListResponse
                                    }
                                );
                            });
                    }
                    )
            } else {
                return;
            }
        }).catch(err => {
            return;
        })
});

router.get("/:user_id", (req, res, next) => {
    User.find({ email: req.userData.email })
        .exec()
        .then(user1 => {
            if (user1.length >= 1) {
                User.find({ primaryId: req.params.user_id })
                    .exec()
                    .then(user2 => {
                        if (user1.length >= 1) {
                            Chat.find({
                                $or: [{ user1: user1[0].primaryId, user2: user2[0].primaryId }
                                    , { user1: user2[0].primaryId, user2: user1[0].primaryId }]
                            })
                                .exec()
                                .then(chat => {
                                    if (chat.length >= 1) {

                                        chat[0].messages.select('-_id message date sentby',).sort({ date: 'descending', id: 'descending' }).exec((err, docs) => {
                                            if (docs.length == 0) {
                                                return res.status(400).json({
                                                    "messages": [
                                                        {
                                                            "message": "Hi",
                                                            "date": 1646739337,
                                                            "sentby": 10
                                                        }
                                                    ]
                                                });
                                            }
                                            res.status(200).json(
                                                {
                                                    "messages": docs
                                                }
                                            );
                                        });

                                    } else {
                                        return res.status(400).json({
                                            "messages": [
                                                {
                                                    "message": "Hi",
                                                    "date": 1646739337,
                                                    "sentby": 10
                                                }
                                            ]
                                        });
                                    }
                                })

                        } else {
                            return res.status(400).json({
                                "error": {
                                    "message": "Bad request!"
                                }
                            });
                        }
                    })
            } else {
                return res.status(400).json({
                    "error": {
                        "message": "Bad request!"
                    }
                });
            }
        })

});

router.post("/:user_id", checkAuth, (req, res, next) => {

    User.find({ email: req.userData.email })
        .exec()
        .then(user1 => {
            if (user1.length >= 1) {
                User.find({ primaryId: req.params.user_id })
                    .exec()
                    .then(user2 => {
                        if (user1.length >= 1) {
                            Chat.find({
                                $or: [{ user1: user1[0].primaryId, user2: user2[0].primaryId }
                                    , { user1: user2[0].primaryId, user2: user1[0].primaryId }]
                            })
                                .exec()
                                .then(chat => {
                                    if (chat.length < 1) {
                                        Chat.count({}, function (err, count) {
                                            const chat = new Chat({
                                                _id: new mongoose.Types.ObjectId,
                                                id: count + 1,
                                                user1ID: user1[0].primaryId,
                                                user2ID: user2[0].primaryId,
                                            });
                                            chat.save()
                                                .then(result => {
                                                })
                                                .catch(err => {
                                                    return res.status(400).json({
                                                        "error": {
                                                            "message": "Bad request!"
                                                        }
                                                    });
                                                });
                                        })
                                    }
                                    const message = new Message({
                                        _id: new mongoose.Types.ObjectId,
                                        id: chat.messages.length + 1,
                                        sentby: user1[0].primaryId,
                                        receiver: user2[0].primaryId,
                                        message: req.body.message,
                                    });
                                    message.save()
                                        .then(result => {
                                            chat.messages.push(result.id);
                                            return res.status(400).json({
                                                "message": "successful"
                                            });
                                        })
                                        .catch(err => {
                                            return res.status(400).json({
                                                "error": {
                                                    "message": "Bad request!"
                                                }
                                            });
                                        });
                                })

                        } else {
                            return res.status(400).json({
                                "error": {
                                    "message": "Bad request!"
                                }
                            });
                        }
                    })
            } else {
                return res.status(400).json({
                    "error": {
                        "message": "Bad request!"
                    }
                });
            }
        })

});


module.exports = router;